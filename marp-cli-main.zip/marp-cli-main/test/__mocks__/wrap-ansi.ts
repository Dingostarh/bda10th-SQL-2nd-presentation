module.exports = jest.fn().mockImplementation((m) => m) // No ops
