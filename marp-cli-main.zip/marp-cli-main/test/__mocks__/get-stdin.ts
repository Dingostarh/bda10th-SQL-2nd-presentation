module.exports = {
  buffer: jest.fn().mockResolvedValue(''),
}
