export default {}

console.debug('A config file with .mjs extension was loaded.')
