module.exports = { engine: './custom-engine.js' }
