module.exports = { engine: import('./custom-engine.js') }
