module.exports = {
  engine: '@marp-team/marpit',
  theme: 'a',
  themeSet: '../../_files/themes/a.css',
}
