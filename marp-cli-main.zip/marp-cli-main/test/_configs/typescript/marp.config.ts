import { defineConfig } from '../../../src/index'

export default defineConfig({
  title: 'TypeScript configuration',
})

console.debug('A config file with .ts extension was loaded.')
