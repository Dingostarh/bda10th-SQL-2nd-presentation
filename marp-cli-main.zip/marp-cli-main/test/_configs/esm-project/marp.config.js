/** @type {import('../../../src/index').Config} */
const config = {}

export default config

console.debug('A config file within ESM project was loaded.')
