---
marp: true
theme: uncover
---

# Hello, I'm Marp CLI!

Write and convert your presentation deck with just a plain Markdown!

<!-- You can also write down presenter notes in HTML comments. -->

---

<!-- backgroundColor: beige -->

## Watch and preview

Marp CLI is supported watch mode and preview window.

---

# <!--fit--> :+1:
