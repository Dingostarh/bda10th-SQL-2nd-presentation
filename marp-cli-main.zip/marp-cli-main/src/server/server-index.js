import serverIndex from './server-index.ts'

serverIndex()
