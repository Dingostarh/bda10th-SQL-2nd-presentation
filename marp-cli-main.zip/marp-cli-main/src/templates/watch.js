import watch from './watch/watch'

watch()
